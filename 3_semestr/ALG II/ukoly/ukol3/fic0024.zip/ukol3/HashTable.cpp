#include "HashTable.h"

// Konstruktor bez parametr�
HashTable::HashTable() : TableSize(10), NumberOfKeys(0) {
    Table.resize(TableSize);
}

// Konstruktor s velikost� tabulky
HashTable::HashTable(const int TableSize) : TableSize(TableSize), NumberOfKeys(0) {
    Table.resize(TableSize);
}

// Destruktor
HashTable::~HashTable() {
    Clear();
}

// Ha�ovac� funkce
int HashTable::HashFunction(const string& Key) const {
    int hash = 2320;
    for (char c : Key) {
        hash += c;
    }
    return hash % TableSize;
}

// Vlo�en� kl��e a hodnoty
void HashTable::Insert(const string& Key, const int NewValue) {
    int index = HashFunction(Key);
    for (auto& pair : Table[index]) {
        if (pair.Key == Key) {
            pair.Value = NewValue;
            return;
        }
    }
    Table[index].push_back({ Key, NewValue });
    NumberOfKeys++;
}

// Hled�n� kl��e
bool HashTable::ContainsKey(const string& Key) const {
    int index = HashFunction(Key);
    for (const auto& pair : Table[index]) {
        if (pair.Key == Key) {
            return true;
        }
    }
    return false;
}

// Z�sk�n� hodnoty podle kl��e
bool HashTable::TryGetValue(const string& Key, int& Value) const {
    int index = HashFunction(Key);
    for (const auto& pair : Table[index]) {
        if (pair.Key == Key) {
            Value = pair.Value;
            return true;
        }
    }
    return false;
}

// Smaz�n� kl��e
void HashTable::Delete(const string& Key) {
    int index = HashFunction(Key);
    auto& slot = Table[index];
    for (auto it = slot.begin(); it != slot.end(); ++it) {
        if (it->Key == Key) {
            slot.erase(it);
            NumberOfKeys--;
            return;
        }
    }
}

// Vy�i�t�n� tabulky
void HashTable::Clear() {
    for (auto& slot : Table) {
        slot.clear();
    }
    NumberOfKeys = 0;
}

// Velikost tabulky
size_t HashTable::GetTableSize() const {
    return TableSize;
}

// Po�et kl���
size_t HashTable::GetNumberOfKeys() const {
    return NumberOfKeys;
}

// Faktor napln�n�
double HashTable::GetLoadFactor() const {
    return static_cast<double>(NumberOfKeys) / TableSize;
}

// Report obsahu
void HashTable::Report() const {
    for (size_t i = 0; i < TableSize; ++i) {
        cout << "Slot " << i << ": ";
        for (const auto& pair : Table[i]) {
            cout << "{" << pair.Key << ", " << pair.Value << "} ";
        }
        cout << endl;
    }
}
