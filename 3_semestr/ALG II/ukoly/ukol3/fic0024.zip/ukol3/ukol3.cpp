#include "HashTable.h"

int main() {
    HashTable ht;

    // Vlo�en� kl��� a hodnot
    ht.Insert("Richard", 25);
    ht.Insert("Petra", 32);
    ht.Insert("Daniel", 20);
    ht.Insert("Charlie", 35);

    // Zobrazen� obsahu
    ht.Report();


    cout << "Vyhledani zaznamu: " << endl;
    // Vyhled�n� hodnoty
    int value;
    if (ht.TryGetValue("Bob", value)) {
        cout << "Hodnota pro kl�� 'Bob': " << value << endl;
    }
    else {
        cout << "Kl�� 'Bob' nebyl nalezen." << endl;
    }


    cout << "Smazani zaznamu: " << endl;
    // Smaz�n� kl��e
    ht.Delete("Alice");
    ht.Report();

    cout << "Aktualiza zaznamu: "<< endl;
    //Aktualizece z�znamu
    ht.Insert("Bob", 40);
    ht.Report();

    // Zobrazen� faktoru napln�n�
    cout << "Faktor napln�n�: " << ht.GetLoadFactor() << endl;

    return 0;
}
