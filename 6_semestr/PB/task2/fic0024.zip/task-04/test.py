h1 ="1de8c2a081b42648be2096a8bc23a32bde4b3fdfd7d43090b40fc92861ee0cdf"
h2 = "976c90c09ee072c2ed946db4d82a5cc2968c82225a7125447bddae612e2491ea"

b1 = bin(int(h1,16))[2:].zfill(256)
b2 = bin(int(h2,16))[2:].zfill(256)

same_bits = sum(bit1==bit2 for bit1,bit2 in zip(b1,b2))
print(same_bits)

