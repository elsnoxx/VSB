#ifndef DATA_H
#define DATA_H

#include <QStringList>

extern QStringList statusList;
extern QStringList typeList;
extern QStringList locationList;
extern QStringList manufacturerList;

#endif
