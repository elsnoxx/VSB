from django.contrib import admin
from django.urls import path, include
from blog import views
from ninja import NinjaAPI
from blog.api import api

urlpatterns = [
    path('', views.index, name='index'),
    path('admin/', admin.site.urls),
    path('guests/', views.guest_list, name='guest_list'),
    path('profile/', views.profile_view, name='profile'),
    path('guests/<int:guest_id>/', views.guest_detail, name='guest_detail'),
    path('guests/new/', views.guest_create, name='guest_create'),
    path('guests/<int:guest_id>/edit/', views.guest_update, name='guest_update'),
    path('guests/<int:guest_id>/delete/', views.guest_delete, name='guest_delete'),
    path('reservations/', views.reservation_list, name='reservation_list'),
    path('reservations/<int:reservation_id>/', views.reservation_detail, name='reservation_detail'),
    path('add-guest/', views.add_guest, name='add_guest'),
    path('reservation/create/<int:room_id>/', views.create_reservation, name='create_reservation'),
    path('reserbation/<int:reservation_id>/update/', views.reservation_update, name='reservation_update'),
    path('reservation/<int:reservation_id>/delete/', views.reservation_delete, name='reservation_delete'),
    path('room/management/', views.room_management, name='room_management'),
    path('room/create/', views.room_create, name='room_create'),
    path('room/<int:room_id>/update/', views.room_update, name='room_update'),
    path('room/<int:room_id>/delete/', views.room_delete, name='room_delete'),
    path('payment_management/', views.payment_management, name='payment_management'),
    path('payment/<int:employee_id>/mark-as-paid/', views.mark_payment_as_paid, name='mark_payment_as_paid'),
    path('payment/<int:reservation_id>/mark-as-paid-from-reservation/', views.mark_payment_as_paid_from_reservation, name='mark_payment_as_paid_from_reservation'),
    path('accounts/login/', views.login_view, name='login'),
    path('accounts/logout/', views.logout_view, name='logout'),
    path('accounts/register/', views.register_view, name='register'),
    path('reservation/<int:reservation_id>/add-service/', views.add_service_to_reservation, name='add_service_to_reservation'),
    path('reservation/<int:reservation_id>/remove-service/<int:usage_id>/', views.remove_service_from_reservation, name='remove_service_from_reservation'),
    path('my-reservations/', views.my_reservations, name='my_reservations'),
    path('service/management/', views.service_management, name='service_management'),
    path('ajax/guest-autocomplete/', views.guest_autocomplete, name='guest_autocomplete'),
    path('api/reservation/<int:reservation_id>/feedback/', views.api_add_feedback, name='api_add_feedback'),
    path('profile/update/', views.profile_update, name='profile_update'),
    path("api/", api.urls),
]
